Quellen: 

Videoquellen: 

Homer_jagt_Bart.mp4: https://www.youtube.com/watch?v=rngVanH1AXY


Bildquellen: 

Bart_Simpson.png: http://www.pngall.com/wp-content/uploads/2016/06/Bart-Simpson-Free-Download-PNG.png
Homer_Simpsons.png: http://img.webme.com/pic/8/8cthebest/homer-simpson-picture.gif
Homer-wuergt-Bart.png: http://5mpx.com/get/index.php?img=Homer-and-Bart-5mpx-com.jpg
Donut.png: http://superawesomevectors.com/wp-content/uploads/2014/03/free-vector-donut-drawing-800x565.jpg	
Homer_Donut.png: http://blog.flinc.org/wp-content/uploads/2014/04/homer-donut-liegend-515x300.png

Soundquellen:

Homer-Schrei.mp3: https://www.youtube.com/watch?v=vWijtCThtw8
m_donuts.mp3: https://www.youtube.com/watch?v=8-4P1WPE-Qg



