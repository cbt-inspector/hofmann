import roboter.*;
import static roboter.werkzeug.Pause.*;

/** 
 * Simulation eines zweidimensionalen Roboters, bestehend aus einem drehbaren
 * Arm, einer Greifhand, einem Flie�band mit Kugeln und zwei T�pfen, in die
 * die Kugeln abgelegt werden k�nnen.
 */
public class Roboter implements Drehgelenkroboter {
    /** Winkel des Arms �ber der Horizontalen rechts im Gegenuhrzeigersinn in Grad
     */ 
    private int armwinkel;
    /** Kugelobjekt, das der Roboter in der Hand h�lt, hat den Wert null, falls
     * keine Kugel in der Hand
     */
    private Kugel kugel;
    /** Flie�bandobjekt, das 10 Kugeln enth�lt. Bei armwinkel gleich 150 Grad kann
     * der Roboter die erste Kugel auf dem Flie�band greifen. Der Wert 0.25 beschreibt
     * die L�nge des Roboterarms.(25 % der Fensterbreite)
     */
    private Fliessband fliessband = new Fliessband(10, 150, 0.25);
    /** Topfobjekte, auf dem Boden stehend, 14 % der Fensterbreite links vom Drehpunkt 
     * und 10 % der Fensterbreite
     * rechts vom Drehpunkt
     */ 
    private Topf topf1 = new Topf(-0.14);
    private Topf topf2 = new Topf(+0.10);   
    /** Klasse, die der grafischen Darstellung des Roboterobjekts dient
     */
    private RoboterGrafik rg;
    private int pauseZwischenBewegungen = 250;//in ms
    
    /** 
     * Der Wert des Armwinkels wird so gesetzt, dass die Greifhand auf der ersten 
     * Kugel am Flie�band ist.
     * Das Objekt f�r die grafische Darstellung wird erzeugt.
     */
    public Roboter(){
        armwinkel = fliessband.relativWinkelRoboterGeben();
        rg = new RoboterGrafik(this, fliessband, topf1, topf2);
    }
    /** 
     * Informiert �ber die Winkelstellung des Arms.
     * Ist der Arm in "3 Uhr Stellung" wird 0 ausgegeben.
     * Ist der Arm am Flie�band, wird 150 ausgegeben.
     * Ist der Arm �ber dem linken Topf, wird 250 ausgegeben.
     */
    public int winkelGeben(){
        return armwinkel;
    }
    /** 
     * Informiert �ber die Farbe der gegriffenen Kugel
     * - wenn der Roboter keine Kugel in der Hand hat, 
     * wird der Wert "" ausgegeben.
     */
    public String kugelfarbeGeben(){
        if (kugel != null){
            return kugel.farbeGeben();
        }
        return "";
    }
    /** 
     * Informiert �ber die Nummer der gegriffenen Kugel.
     * - wenn der Roboter keine Kugel in der Hand hat,
     * wird der Wert 0 ausgegeben.
     */
    public int kugelnummerGeben(){
        if (kugel != null){
            return kugel.nummerGeben();
        }
        return 0;
    }
    /** 
     * Drehen des Arms um den vom Nutzer eingegebenen Wert im Gegenuhrzeigersinn.
     * Der Arm nimmt nur dann eine Kugel mit, wenn er sie vorher gegriffen hat.
     * Will man vom Flie�band zum linken Topf kommen, gibt man 100 ein.
     * Will man vom Flie�band zum rechten Topf kommen, gibt man 160 ein.
     */
    public void drehen(int winkel){
        armwinkel = (armwinkel + winkel)%360;
        if (armwinkel < 0){
            armwinkel = armwinkel + 360;
        }

        neuzeichnen();
    }
    /** 
     * Greifen einer Kugel, falls eine solche direkt unter 
     * der Greifhand liegt.
     */
    public void greifen(){
        if (kugel == null && umschliesstKugel()){
                kugel = fliessband.kugelEntfernen();  
                fliessband.kugelnTransportieren();
                neuzeichnen();
        }
    }
    /** 
     * Loslassen der Kugel in der Greifhand. 
     * Befindet sich die Greifhand senkrecht �ber einem der beiden T�pfe,
     * f�llt sie in ihn hinein. 
     */
    public void loslassen(){
        if (kugel != null){
            double x = (fliessband.armLaengeGeben() + kugel.radiusGeben())* Math.cos(armwinkel*3.14159265/180);
            topf1.hineinfallen(x);
            topf2.hineinfallen(x);
            kugel = null;
            neuzeichnen();
        }
    }
    /** Gibt genau dann true zur�ck, wenn die Greifhand die erste Kugel auf dem Flie�band umschlie�t.
     */ 
    private boolean umschliesstKugel(){
        return armwinkel == fliessband.relativWinkelRoboterGeben();
    }
    
    private void neuzeichnen(){
        rg.repaint();
        msWarten(pauseZwischenBewegungen);            
    }
}
