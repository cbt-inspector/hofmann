package roboter;

/** Kugelobjekt, das von einem Objekt der Klasse Roboter
 * transportiert werden kann
 */
public class Kugel{
    /** Nummer auf der Kugel
     */
    private int nummer;
    /** Farbe der Kugel, z. B. "blau"
     */
    private String farbe;
    /** Radius der Kugel als Anteil der Fensterbreite
     */
    private double radius = 0.0225;
    
    /** Konstruktor
     * �bergabe der Nummer und der Farbe als Eingangsparameterwerte
     */
    public Kugel(int nr, String f){
        nummer = nr;
        farbe = f;
    }
    /** Gibt die Nummer der Kugel zur�ck.
     */
    public int nummerGeben(){
        return nummer;
    }
    /** Gibt die Farbe der Kugel als String-Wert zur�ck.
     */
    public String farbeGeben(){
        return farbe;
    }
    /** Gibt den Radius der Kugel als Anteil der Fensterbreite zur�ck.
     */
    public double radiusGeben(){
        return radius;
    }
}