package roboter.werkzeug;
import static java.util.concurrent.TimeUnit.*;

/**
 * Die Klasse Pause stellt Dienste zum Warten bereit.
 * 
 * @author 
 * @version 
 */
public class Pause{
    /**
     * Warten
     * 
     * @param  zeit   Zeit in Sekunden
     */
    public static void warten(int sekunden){
        msWarten(sekunden * 1000);
    }

    /**
     * Warten
     * 
     * @param  zeit   Zeit in Millisekunden
     */ 
    public static void msWarten(int ms){
        try{
            MILLISECONDS.sleep(ms);
        } catch(InterruptedException e) {
            System.err.println("sleep wurde unterbrochen");    
        }
    }
}
