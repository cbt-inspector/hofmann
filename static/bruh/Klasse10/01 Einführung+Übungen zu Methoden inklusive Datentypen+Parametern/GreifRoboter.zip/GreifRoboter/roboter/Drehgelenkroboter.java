package roboter;

/**
 * Nur fuer das Kapitel 1.1 des Schulbuchs. Wir verstecken Beziehungen vor dem
 * Benutzer ohne das Projekt f�r Kapitel 3 von Frank Fiedler nennenswert zu ver-
 * aendern.
 * 
 * @author Heuer 
 * @version 
 */

public interface Drehgelenkroboter
{
    public String kugelfarbeGeben();
    public int kugelnummerGeben();
    public int winkelGeben();
}
