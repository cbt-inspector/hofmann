package roboter;

import javax.swing.*;
import java.awt.*;

/** Klasse, die zur grafischen Darstellung eines Roboterobjekts
 *  in einem Fenster (JFrame) dient
 */
public class RoboterGrafik extends JFrame{
    /** darzustellendes Roboterobjekt
     */
    private Drehgelenkroboter roboter;
    /** Breite und H�he des quadratischen Fensters in Pixeln
     */
    private int breite=500;
    /** darzustellendes Flie�band, Referenz auf das Attribut gleichen Namens
     * des Objekts roboter. Diese Art der Umsetzung wurde gew�hlt, um der 
     * Klasse Roboter, deren Dienste die Sch�ler nutzen sollen, sondierende 
     * Methoden wie z.B. fliessbandGeben() zu ersparen, die die Sch�ler 
     * nicht sehen sollen.
     */
    private Fliessband fliessband;
    /** darzustellende T�pfe
     */
    private Topf topf1, topf2;
    /** Radius der darzustellenden Kugeln
     */
    private int kugelRadius;

    /** Konstruktor
     * �bergabe des Roboterobjekts, seines Flie�bandes und seiner T�pfe,
     * Erzeugung und Anzeige des Grafikfensters
     */
    public RoboterGrafik(Drehgelenkroboter r, Fliessband flb, Topf t1, Topf t2){
        roboter = r;
        fliessband = flb;
        topf1 = t1;
        topf2 = t2;
        setTitle("Informatik-Roboter");
        setSize(breite, breite);
        repaint();
        setVisible(true);
    }
    /** Umwandlung der als Parameter �bergebenen Farbe vom Typ String in ein Objekt der 
     * Klasse Color
     */
    private Color stringToColor(String farbe){
        if (farbe == "rot") return Color.red;
        if (farbe == "blau") return Color.blue;
        if (farbe == "gr�n") return Color.green;
        if (farbe == "magenta") return Color.magenta;
        if (farbe == "wei�") return Color.white;
        return new Color(50,50,50);
    }
    /** Grafische Darstellung einer Kugel
     * Farbe, Nummer und Position (x- und y- Koordinate) werden als Parameter �bergeben
     */
    private void kugelZeichnen(Graphics g, String kugelFarbe, int kugelNummer, int x, int y){
            int durchmesser = 2*kugelRadius;
            g.setColor(stringToColor(kugelFarbe));
            g.fillOval(x, y, durchmesser, durchmesser);
            g.setColor(Color.white);
            if (stringToColor(kugelFarbe).equals(Color.white)){
                g.setColor(Color.black);
            }
            g.setFont(new Font("Courier", Font.BOLD, (int)(durchmesser/2)));
            double xfaktor = 0.25;
            kugelNummer = kugelNummer % 100;
            if (kugelNummer < 10){
                xfaktor = 0.375;
            }
            int nummerX = x + (int)(xfaktor*durchmesser);
            int nummerY = y + (int)(0.75*durchmesser);
            g.drawString(String.valueOf(kugelNummer), nummerX, nummerY);
    }
    /** Grafische Darstellung des Flie�bandes
     * Die Breite (Dicke) der grafischen Darstellung des Flie�bandes (in Pixel) und die 
     * Koordinaten der ersten Kugel (ganz rechts) auf dem Flie�band werden als Parameter �bergeben.
     */
    private void fliessbandZeichnen(Graphics g, int fliessbandBreite, int kugel0X, int kugel0Y){
        int kugelDurchmesser = 2 * kugelRadius;
        int kugelAbstand = (int) (1.1 * kugelDurchmesser); 
        for (int i = 0; i < fliessband.laengeGeben(); i++){
            if (fliessband.kugelGeben(i) != null){
                kugelZeichnen(g, fliessband.kugelGeben(i).farbeGeben(), fliessband.kugelGeben(i).nummerGeben(), 
                                    kugel0X-i*kugelAbstand, kugel0Y);
            }
        }
        g.setColor(Color.yellow);
        int fliessbandLaenge = fliessband.laengeGeben()* kugelAbstand;
        g.fillRect(kugel0X - fliessbandLaenge+kugelDurchmesser, kugel0Y+kugelDurchmesser, fliessbandLaenge, fliessbandBreite);
    }
    /** Grafische Darstellung eines Topfes
     * Das Topfobjekt, die Position des Drehpunktes des Roboterarms und die Farbe der grafischen
     * Darstellung des Topfes m�ssen als Parameter �bergeben werden.
     * (Die Klasse Topf besitzt ein Attribut, das seine Position relativ zum Drehpunkt beschreibt.)
     */
    private void topfZeichnen(Graphics g, Topf topf, int drehpunktX, Color color){
        int topfhoehe = (int)(breite/7);
        int topfbreite = (int)(topf.breiteGeben()*breite);
        int[] x = new int[4];
        int[] y = new int[4];
        x[0] = (int)(drehpunktX + topf.relativDrehpunktXGeben()*breite);
        y[0] = breite - topfhoehe;
        y[3] = y[0];
        x[1] = (int)(x[0] + 0.13 * topfbreite);
        y[1] = breite;
        y[2] = breite;
        x[3] = x[0] + topfbreite;
        x[2] = (int)(x[3] - 0.13 * topfbreite);
        g.setColor(color);
        g.fillPolygon(x,y,4);
        g.setColor(Color.white);
        if (color.equals(Color.white)){
            g.setColor(Color.black);
        }
        g.setFont(new Font("Courier", Font.BOLD, (int)(topfbreite*0.4)));
        double xfaktor = 0.4;
        int kugelzahl = topf.kugelzahlGeben()%1000;
        if (kugelzahl > 9){
            if (kugelzahl >99){
                xfaktor = 0.175;
            }
            else{
                xfaktor = 0.25;
            }
        }
        int zahlX = x[0] + (int)(xfaktor*topfbreite);
        int zahlY = y[0] + (int)(0.7*topfhoehe);
        g.drawString(String.valueOf(kugelzahl), zahlX, zahlY);
    }
    /** Komplette grafische Darstellung von Arm, Greifhand, Kugel in der 
     * Greifhand, Flie�band und T�pfen
     * Die H�he des Fensters wird der aktuellen Breite angepasst, sodass
     * das Fenster immer quadratisch ist.
     */
    public void paint(Graphics g){
        breite = getWidth();
        setSize(breite, breite);
        kugelRadius = (int)(breite * 0.0225);
        int rwr = fliessband.relativWinkelRoboterGeben();
        double bogen = roboter.winkelGeben()*3.14159265/180;
        double bogenAmFliessband = rwr * 3.14159265/180;
        String kugelFarbe = roboter.kugelfarbeGeben();
        int kugelNummer = roboter.kugelnummerGeben();
        boolean gegriffen = (kugelFarbe != "");
        int drehpunktX = (int)(5*breite/8);
        int drehpunktY = (int)(3*breite/8);
        int armdicke = (int) (breite/40);
        int radius = (int)(armdicke/2);
        int armlaenge = (int)(breite*fliessband.armLaengeGeben());
        int radiusoffen = (int)(kugelRadius*1.4);
        double ex = Math.cos(bogen);
        double ey = -Math.sin(bogen);
        double nx = -ey;
        double ny = ex;
        int armendeMitteX = (int) (ex * armlaenge) + drehpunktX;
        int armendeMitteY = (int) (ey * armlaenge) + drehpunktY;       
        int[] x = new int[4];
        int[] y = new int[4];
        x[0] = armendeMitteX - (int)(nx * radius);
        y[0] = armendeMitteY - (int)(ny * radius);
        x[1] = armendeMitteX + (int)(nx * radius);
        y[1] = armendeMitteY + (int)(ny * radius);
        x[2] = drehpunktX + (int)(-ex*radius + nx * radius);
        y[2] = drehpunktY + (int)(-ey*radius + ny * radius);
        x[3] = drehpunktX + (int)(-ex*radius - nx * radius);
        y[3] = drehpunktY + (int)(-ey*radius - ny * radius);
        int kugel0X = drehpunktX + (int)(Math.cos(bogenAmFliessband)*(armlaenge+radiusoffen)-kugelRadius);
        int kugel0Y = drehpunktY + (int)(-Math.sin(bogenAmFliessband)*(armlaenge+radiusoffen)-kugelRadius);
        
        Color roboterfarbe = new Color(180,200,233);
        
        g.setColor(Color.black);
        g.fillRect(0,0,breite,breite);
        
        fliessbandZeichnen(g, breite/80, kugel0X, kugel0Y);
        
        g.setColor(roboterfarbe);
        g.fillPolygon(x, y, 4);
        int griffRadius = radiusoffen;
        if (gegriffen){
            griffRadius = kugelRadius;
        }
        int griffX = (int)(armendeMitteX + (ex-1) * griffRadius);
        int griffY = (int)(armendeMitteY + (ey-1) * griffRadius);
        if (kugelFarbe != ""){
            kugelZeichnen(g, kugelFarbe, kugelNummer, griffX, griffY);
            g.setColor(roboterfarbe);
        }
        g.drawOval(griffX, griffY, griffRadius*2, griffRadius*2);
        g.setColor(new Color(50,50,50));
        g.drawOval(drehpunktX-radius, drehpunktY-radius, armdicke-1, armdicke-1);

        topfZeichnen(g, topf1, drehpunktX, new Color(125,125,0));
        topfZeichnen(g, topf2, drehpunktX, new Color(0,150,0));       
    }
}