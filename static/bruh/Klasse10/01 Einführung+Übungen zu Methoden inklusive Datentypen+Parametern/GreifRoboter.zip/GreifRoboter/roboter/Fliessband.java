package roboter;

import java.util.Random;

/** Objekte der Klasse Flie�band sind Bestandteile von Objekten der Klasse Roboter.
 * Sie transportieren Objekte der Klasse Kugel, die die Greifhand des Roboters aufnehmen kann.
 */
public class Fliessband{
    /** maximale Anzahl der Kugeln auf dem Flie�band
     */
    private int laenge;
    /** Feld, das auf die Kugelobjekte auf dem Flie�band verweist
     */
    private Kugel[] kugel;
    /** Zufallsgenerator zur Erzeugung der Farben und der Nummern neuer Kugeln
     */
    private Random random;
    /** Nummer der n�chsten Kugel, die neu links auf das Flie�band gesetzt wird
     */
    private int aktuelleNummer;
    /** Winkelstellung des Roboterarms in Grad, unter dem die Greifhand des Roboters 
     * auf der ersten Kugel ist. Dieses Attribut ist eine Polarkoordinate zur Beschreibung 
     * der Position des Flie�bandes.
     */
    private int relativWinkelRoboter;
    /** zweite Polarkoordinate; Abstand der ersten Kugel vom Drehpunkt des Roboterarmes
     * als Anteil der Fensterbreite 
     */
    private double armLaenge;

    /** Konstruktor
     * �bergabe der maximalen Kugelzahl und der Position des Flie�bandes gegen�ber dem Drehpunkt 
     * und der Anfangswerte f�r die Attribute relativWinkelRoboter und armLaenge
     */
    public Fliessband(int l, int relativWinkel, double aL){   
        random = new Random();    
        laenge = l;
        relativWinkelRoboter = relativWinkel;
        armLaenge = aL;
        kugel = new Kugel[laenge];
        aktuelleNummer = 0;
        for (int i = 0; i < laenge; i++){
            kugel[i] = neueKugel();
        }   
    }
    /** Methode, die ein neues Kugelobjekt zuf�lliger Farbe erzeugt
     * und dieses an den Nutzer zur�ckgibt
     */
    public Kugel neueKugel(){
        aktuelleNummer = aktuelleNummer + 1;
        String s = "";
        int zufallszahl = random.nextInt(5);
        switch(zufallszahl){
            case 0: s = "rot"; break;
            case 1: s = "magenta"; break;
            case 2: s = "gr�n"; break;
            case 3: s = "blau"; break;
            case 4: s = "wei�"; break;
        }
        return new Kugel(aktuelleNummer, s);
    }
    /** Die erste Kugel auf dem Flie�band wird entfernt und das entsprechende Objekt 
     * an den Nutzer zur�ckgegeben.
     */
    public Kugel kugelEntfernen(){
        Kugel k = kugel[0];
        kugel[0] = null;
        return k;
    }
    /** Alle Kugeln auf dem Flie�band werden um eine Position nach rechts transportiert.
     * Ist auf der Position ganz rechts eine Kugel, f�llt sie vom Band. Auf die Position
     * ganz links auf dem Band wird eine neu erzeugte Kugel gesetzt.
     */
    public void kugelnTransportieren(){
        for (int i = 0; i < laenge-1; i++){
            kugel[i] = kugel[i+1];
        }
        kugel[laenge -1] = neueKugel();
    }
    /** Gibt die Kugel auf der (i+1)-ten Position (von rechts gez�hlt) zur�ck.
     */
    public Kugel kugelGeben(int i){
        return kugel[i];
    }
    /** Gibt die maximal m�gliche Zahl an Kugeln auf dem Flie�band zur�ck.
     */
    public int laengeGeben(){
        return laenge;
    }
    /** Gibt die Winkelstellung des Roboterarms in Grad, wenn sich die Greifhand auf der
     * ersten Kugel befindet, zur�ck.
     */
    public int relativWinkelRoboterGeben(){
        return relativWinkelRoboter;
    }
    /** Gibt die L�nge des Roboterarms als Anteil der Fensterbreite zur�ck.
     */
    public double armLaengeGeben(){
        return armLaenge;
    }
}