package roboter;

/** Objekte der Klasse Topf sind Bestandteile von Objekten der Klasse Roboter.
 * Sie k�nnen Objekte der Klasse Kugel, die ein Roboter losl�sst, auffangen und z�hlen.
 */
public class Topf{
    /** x- Koordinate der Position des linken Topfrands relativ zum Drehpunkt 
     * des Roboterarmes als Anteil der Fensterbreite
     */
    private double relativDrehpunktX;  //  Wert zwischen 0 und 100 % = 1
    /** Breite des Topfes als Anteil der Fensterbreite
     */
    private double breite = 0.12;
    /** Zahl der Kugel, die in den Topf gefallen sind 
     */
    private int anzahlKugeln = 0;
   
    /** Konstruktor
     * Die x-Koordinate der Position relativ zum Dehpunkt wird als Parameter
     * �bergeben.
     */
    public Topf (double x){
        relativDrehpunktX = x;
    }
    /** Gibt die x-Koordinate der Position relativ zum Drehpunkt als Anteil der
     * Fensterbreite zur�ck.
     */
    public double relativDrehpunktXGeben(){
        return relativDrehpunktX;
    }
    /** Gibt die Breite des Topfes als Anteil der Fensterbreite zur�ck.
     */
    public double breiteGeben(){
        return breite;
    }
    /** Gibt die Zahl der in den Topf gefallenen Kugeln zur�ck.
     */
    public int kugelzahlGeben(){
        return anzahlKugeln;
    }
    /** Die Methode hineinfallen(double x) wird aufgerufen, wenn eine Kugel
     * von einer Position mit der x-Koordinate x (als Anteil relativ zur
     * Fensterbreite) losgelassen wird. Die Methode pr�ft, ob x innerhalb
     * des linken und des rechten Randes des Topfes liegt, und erh�ht in 
     * diesem Fall den Wert des Attributs anzahlKugeln um 1.
     */
    public void hineinfallen(double x){
        if ((relativDrehpunktX < x) && (relativDrehpunktX + breite > x)){
            anzahlKugeln = anzahlKugeln + 1;
        }
    }
}