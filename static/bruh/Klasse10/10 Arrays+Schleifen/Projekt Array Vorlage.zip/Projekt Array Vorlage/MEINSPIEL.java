public class MEINSPIEL extends SPIEL{
    FIGUR obb;
    FIGUR[] plattformen;

    public MEINSPIEL(){
        super();
        obb = new FIGUR("obb.png");
        plattformen = new FIGUR[50];
        obb.macheAktiv();
        setzeKamerafokus(obb);
        
        
        //TODO plattformen erstellen
        
        
        
        
        
        
        

        
        tickerNeuStarten(0.07);   
    }

    public void tick(){
        if(tasteGedrueckt(TASTE.RECHTS)){
            obb.verschiebenUm(0.5, 0);
        }
        if(tasteGedrueckt(TASTE.LINKS)){
            obb.verschiebenUm(-0.07, 0);
        }
    }

    public void tasteReagieren(int taste){
        if(taste == TASTE.RAUF){
            obb.springe(12);
        }
    }

    
}