public class BeispielprogrammMitRunnable {

public static void main(String[] args) throws Exception{ //Notwendig damit das Programm nicht "abstürzt", falls ein Thread interrupted/unterbrochen wird.

    Thread[] t = new Thread[10];    //Standard-Thread-Klasse von Java
            for (int i = 0; i < t.length; i++) {
                t[i]=new Thread(new MeinRunnable(i));   //Arbeitspaket wird an Thread übergeben
                //Daten, die das Arbeitspaket für die Berechnungen benötigt, müssen übergeben werden.
            }
            for (int i = 0; i < t.length; i++) {
                t[i].start(); //Die Threads werden gestartet und parallel ausgeführt.

            }
            for (int i = 0; i < t.length; i++) {
                    t[i].join(); //Der Main-Thread wartet bis die gestarteten Threads fertig gearbeitet haben.
                                 //join() darf nie derselben Schleife wie start() stehen!

            }
            //Ende des Programms
        }
}

class MeinRunnable implements Runnable {
        int nummer;

        public MeinRunnable(int nummer){ //Die übergebenen Daten müssen in Attributen "gespeichert" werden.
            this.nummer = nummer;
        }

        public void run(){
            for (int i = 0; i < 10; i++) {
                System.out.println("Ich bin Arbeitspaket "+nummer);
            }
        }
}

