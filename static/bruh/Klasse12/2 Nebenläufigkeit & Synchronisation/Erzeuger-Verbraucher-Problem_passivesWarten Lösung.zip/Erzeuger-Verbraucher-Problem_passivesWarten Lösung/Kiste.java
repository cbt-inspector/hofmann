
public class Kiste
extends BILD
{
    
    public Kiste(int x, int y)
    {
        super(x,y,"paket.jpg");
    }
}
