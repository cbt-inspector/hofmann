
public interface Function {

	/**
	 * @param x
	 * @return the value of the function at position x
	 */
	public double compute(double x);
	
}
