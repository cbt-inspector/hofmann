import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

public class MonteCarloImpl implements MonteCarlo{


    public static void main(String[] args) {
        MonteCarloImpl m = new MonteCarloImpl();
        Polynomial p = new Polynomial(new double[]{1,0,1}); //die Parameter sind andersrum sortiert also: 1x²+0x+0 -> new Polynomial(new double[]{0,0,1})
        Kreis k = new Kreis();
        System.out.println(m.computeIntegral(p,0,1,0,2,4,10000000)); //Ergebnis: 1.333333333
        System.out.println(m.computeIntegral(k,-1,1,0,1,4,10000000)*2); //Ergebnis: PI
    }
//1.) Vorbereitung: Berechne wie viele Punkte/Koordinaten jeder Thread berechnen muss
//Hinweis: iterations/threads muss nicht ganzzahlig aufgehen. Der Rest (Modulo-Rechnung) muss EIN Thread zusätzlich berechnen. 
//2.) Entscheide, wie du zählen möchtest (-> Counter siehe Anleitung unten)
//3.) Erzeuge deine Threads und Arbeitspakete und übergib die wichtigen Referenzen und Variablen (Vergiss nicht die Extrabehandlung für den "Rest" der Koordinaten)
//4.) Warte auf Beendigung der Berechnungen
//5.) Ergebnis: Das Verhältnis zwischen gezählten Punkten und insgesamten Punkte muss auf die Größe des Fensters multipliziert werden 
//und rot gestreife Feld muss abgezogen/addiert (Tipp: Betrag) werden -> siehe Präsentation
    @Override
    public double computeIntegral(Function f, double a, double b, double minY, double maxY, int threads, long iterations) {
        Thread[] t = new Thread[threads];
        long proIter = (long)iterations/threads;
        long rest = iterations%threads;

        //TODO Schritt 2-4
            



        

        double ergebnis;
        if (minY < 0) {
            ergebnis = ((double) ->hier counter einfügen<- / iterations) * (b - a) * (maxY - minY) - (b - a) * Math.abs(minY);
        } else {
            ergebnis = ((double) ->hier counter einfügen<- / iterations) * (b - a) * (maxY - minY) + (b - a) * Math.abs(minY);
        }

        return ergebnis;
    }
}
//Schreibe eine Klasse Monte implements Runnable, die eine übergebene Funktion numerisch integriert.
//1.) Konstruktor: Übergib alle nötigen Referenzen und Variablen, die für die Berechnungen nötig sind
//2.1) Algorithmus: Jedes Arbeitspaket generiert sich eine zufällige Koordinate innerhalb des Fensters (a,b,minY,maxY) -> java.util.Random
//2.2) Falls die Zufallskoordinate unterhalb des Funktionswerts liegt, dann zähle einen Counter hoch
//Tipp: Du kannst als Counter eine Atomic-Klasse verwenden -> java.util.concurrent.atomic.AtomicLong
