import java.util.concurrent.locks.ReentrantLock;

public class Gabel extends ReentrantLock {

	final int id;

	public Gabel(int id){
		this.id = id;
	}

	public int getId(){
		return id;
	}


}
