public class MehrerePublicKlassen {



    public class ZweitePublicKlasse{ //Innerhalb der anderen Klasse darf diese auch public sein

    }
}
