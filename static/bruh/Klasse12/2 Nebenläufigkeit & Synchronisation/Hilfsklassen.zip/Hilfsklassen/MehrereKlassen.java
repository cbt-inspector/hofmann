public class MehrereKlassen {


}

class ZweiteKlasse { //Diese Klasse darf nicht public sein

}
