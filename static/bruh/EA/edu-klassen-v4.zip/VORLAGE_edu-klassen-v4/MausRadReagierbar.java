
/**
 * Interface MausRadReagierbar. Fordert auf zum Ueberschreiben der Methode mausRadReagieren( int zaehler ).
 * Die Methode wird automatisch beim Betaetigen des Mausrads aufgerufen. 
 * Ihr wird eine ganze Zahl uebergeben, die Auskunft ueber die Drehrichtung gibt.
 * 
 * @author      mike_gans@yahoo.de  and michael andonie
 * 
 * @version     4.0 (2020-01-04)
 */

public interface MausRadReagierbar
extends ea.edu.event.MausRadReagierbar
{
    
}
