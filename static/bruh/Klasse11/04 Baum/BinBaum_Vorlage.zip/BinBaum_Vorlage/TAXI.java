
public class TAXI implements AUFLISTBAR {
    
    private String kfz;

    public TAXI(String kfz) {
        this.kfz = kfz;
    }

    @Override
    public String info() {
        return this.kfz;
    }
    
    @Override
    public boolean istGleich(AUFLISTBAR a) {
        if ( this.info().compareTo( a.info() )  ==  0 ) {
            return true;
        }
        else {
            return false;
        }
    }
    
    @Override
    public boolean istGroesserAls(AUFLISTBAR a) {
        if ( this.info().compareTo( a.info() )  >  0 ) {
            return true;
        }
        else {
            return false;
        }
    }
    
    @Override
    public boolean istKleinerAls(AUFLISTBAR a) {
        if ( this.info().compareTo( a.info() )  <  0 ) {
            return true;
        }
        else {
            return false;
        }
    }
}