
public interface AUFLISTBAR
{
    public abstract String info();
    
    public abstract boolean istGleich(AUFLISTBAR a);
    
    public abstract boolean istGroesserAls(AUFLISTBAR a);
    
    public abstract boolean istKleinerAls(AUFLISTBAR a);
}