
public abstract class ELEMENT<T extends AUFLISTBAR>{
   
    //Methoden fuer das Geruest
    
    public abstract ELEMENT<T> nenneRechtenNf();
    
    public abstract ELEMENT<T> nenneLinkenNf();

    public abstract void setzeRechtenNf(ELEMENT<T> e);
    
    public abstract void setzeLinkenNf(ELEMENT<T> e);
    
    public abstract T inhalt();
    
    public abstract String infoGeben();
    
    //ab hier neue Methoden aus den Skript
    
    
}
