
public class TestklasseCasten{
    private Dackel d;
    private Zirkushund z;
    private Hund h;
    
    
    public TestklasseCasten(){
        double a = 1.0; // einem double wird ein double zugewiesen
        System.out.println(a);
        double b = 1; //1 ist ein Integer -> implizierter Cast
        System.out.println(b);
        
        
        double t = 1.234;
        int g = (int) t;//explizierter Cast; klappt nur bei Zahlen/primitiven Datentypen
        System.out.println(g);
        
        
        d = new Dackel(2,"Dackel");
        z = new Zirkushund(3,"zirki1","Wurst");
        h = new Zirkushund(5,"zirki2","Senf");
       
        z.salto();
        //h.salto(); //Ein normaler Hund kann kein Salto
        
        ((Zirkushund) h).salto(); 
        // klappt nur, weil das Objekt von h bereits ein Zirkushund war
        //ansonten ClasscastException

    }
}
