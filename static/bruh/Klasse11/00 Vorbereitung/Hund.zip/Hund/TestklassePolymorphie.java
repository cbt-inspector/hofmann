public class TestklassePolymorphie{
    private Hund h;
    private Dackel d;
    private Zirkushund z;

    public TestklassePolymorphie(){
        d = new Dackel(2,"Dackel");
        z = new Zirkushund(3,"zirki1","Wurst");
        h = new Zirkushund(5,"zirki2","Senf");
  
        z.bellen(); 
        h.bellen();
        //bei beiden Aufrufen wird die Methode aus dem Zirkushund gewählt 
        d.bellen();
        //der Dackel besitzt kein eigenes Bellen, daher wird die Methoden von Hund gewählt   
    }

    
}
