public class TestklasseReferenzen{
    private Hund h;
    private Dackel d;

    public TestklasseReferenzen(){
        h = new Dackel(1,"Bello");
        //d = new Hund(2,"Kylo");

    }

    
}