public class Dackel extends Hund{
    // nichts Neues

    public Dackel(int alter, String name){
        super(alter, name);
    }



}
