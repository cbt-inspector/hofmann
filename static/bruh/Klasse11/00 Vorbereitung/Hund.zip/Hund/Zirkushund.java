public class Zirkushund extends Hund{
    private String lieblingsfutter;

    public Zirkushund(int alter, String name, String lieblingsfutter){
        super(alter, name);
        this.lieblingsfutter = lieblingsfutter;
    }
    
    @Override
    public void bellen(){
        System.out.println("Zirkushund: bell");
    }
    
    public void salto(){
        System.out.println("allehopp ... jippie !");
    }

    
}
