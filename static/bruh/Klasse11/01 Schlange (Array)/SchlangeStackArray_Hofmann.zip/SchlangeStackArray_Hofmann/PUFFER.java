public abstract class PUFFER<T extends AUFLISTBAR>{
    protected int anzahl;
    protected int max_anzahl;
    protected AUFLISTBAR[] elemente;

    public PUFFER(int laenge){
        elemente = new AUFLISTBAR[laenge];
        anzahl = 0;
        max_anzahl = laenge;
    }

    public boolean istLeer(){
        if(anzahl == 0){
            return true;
        }else{
            return false;
        }
    }

    public boolean istVoll(){
        if(anzahl == max_anzahl){
            return true;
        }else{
            return false;
        }
    }

    public int nenneAnzahl(){
        return anzahl;
    }
    
    public T vorneEntnehmen(){
        if(istLeer() == true){
            return null;
        }
        else {
            AUFLISTBAR t = elemente[0];
            for(int i = 0; i < elemente.length-1;i++){
                elemente[i] = elemente[i+1];
            }
            elemente[max_anzahl-1] = null; //Sonderfall, falls Schlange voll
            anzahl--; 
            return (T)t;
        }
    }

}