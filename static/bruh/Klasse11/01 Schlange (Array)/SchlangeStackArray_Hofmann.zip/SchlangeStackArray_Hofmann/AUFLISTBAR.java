
public interface AUFLISTBAR {

    public String info();
}
