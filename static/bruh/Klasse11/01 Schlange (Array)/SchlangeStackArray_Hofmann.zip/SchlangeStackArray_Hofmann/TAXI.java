
public class TAXI implements AUFLISTBAR{
    
    private String kfz;

    public TAXI(String k){
        kfz = k;
    }

    public String info(){
        return kfz;
    }
}
