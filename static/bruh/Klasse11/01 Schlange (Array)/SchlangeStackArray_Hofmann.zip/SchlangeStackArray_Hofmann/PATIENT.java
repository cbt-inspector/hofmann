
public class PATIENT implements AUFLISTBAR{
    
    private String leiden;

    public PATIENT(String k){
        leiden= k;
    }

    public String info(){
        return leiden;
    }
}
