public class STACK<T extends AUFLISTBAR> extends PUFFER<T>{
    
    public STACK(int n){
        super(n);
    }
    
    
    public boolean vorneEinreihen(T t){
        if(anzahl < elemente.length){
            for(int i = anzahl-1; i >= 0; i--){
                elemente[i+1] = elemente[i];
            }
            elemente[0] = t;
            anzahl++;
            return true;
        } else {
            return false;
        }
      
        
        
        
    }
    
    
    
    
}