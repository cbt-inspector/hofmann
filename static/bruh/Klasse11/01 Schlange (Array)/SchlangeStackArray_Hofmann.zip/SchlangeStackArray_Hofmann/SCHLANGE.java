
public class SCHLANGE<T extends AUFLISTBAR> extends PUFFER<T>{
    
    public SCHLANGE(int n){
        super(n);
    }

    public boolean hintenEinreihen(T t){
        if(istVoll() == false){
            elemente[anzahl] = t;
            anzahl++;
            return true;
        } else {
            return false;
        }

    }

    

}
