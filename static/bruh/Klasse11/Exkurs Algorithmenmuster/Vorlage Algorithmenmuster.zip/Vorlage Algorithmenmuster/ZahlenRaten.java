import java.util.Scanner;
public class ZahlenRaten{
    Scanner scanner;
    public ZahlenRaten(){
        scanner = new Scanner(System.in); //Antwort einlesen
    }

    public int rateIterativ(int anfang, int ende){

        return 0;

    }

    public int rateRekursiv(int anfang, int ende){

        return 0;

    }
}
