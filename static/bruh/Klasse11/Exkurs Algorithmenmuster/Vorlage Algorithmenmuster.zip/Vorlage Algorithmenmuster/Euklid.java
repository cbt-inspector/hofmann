
public class Euklid{
    
    public double euklidIterativ(double a, double b){
        return 0;
    }

    public double euklidRekursiv(double a, double b){
        return 0;
    }
}
