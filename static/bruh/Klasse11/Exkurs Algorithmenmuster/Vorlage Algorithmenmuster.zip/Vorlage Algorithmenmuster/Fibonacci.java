import java.math.BigInteger;

public class Fibonacci{

    
    public void fibRek(int n){
        System.out.println("Hier Hilfsmethode aufrufen");
    }

    
    public void fibIter(int n){
        System.out.println("Hier Hilfsmethode aufrufen");
    }

   

    public void fibDP(int n){
        System.out.println("Hier Hilfsmethode aufrufen");
    }

    
}
