
public class Nullstellensuche{

    private final double epsilon = 0.000001;

    public Nullstellensuche(){

    }

    public double f(double x){
        //bei return eine Funktion angeben im Moment: -3x^2+4 mit Nullstelle bei 1.1547
        return (-3*x*x+4);
    }

    public double sucheNullstelleImIntervall(double x1, double x2){
        if(f(x1)>0 && f(x2)>0 || f(x1)<0 && f(x2)<0){
            System.out.println("Keine Nullstelle in diesem Intervall");
            return -1;
        }
        
        //TODO Nullstellensuche
       
        return 0; 
    }

}
