public class Backtracking{
    
    public boolean fill(int n, int[] a) { 
        return false;
    }

    

    public void testFill(){
        for(int i = 2; i <=10 ; i++){
            System.out.println(i +"  "+fill(i,new int[2*i]));
        }
    }

    private void printLoesungFill(int[] a){
        System.out.print("[");
        for(int i = 0; i < a.length ; i++){
            if(i == a.length -1){
                System.out.print(a[i]);
            }else{
                System.out.print(a[i]+",");
            }
        }
        System.out.print("]");
        System.out.println("");
    }
}
