import java.util.Arrays;

public class MergeSort {

    public void mergeSort(int[] arr) {

    }

    public void merge(int[] left, int[] right, int[] arr) {

    }

    public void testMerge(){
        int[] left = new int[]{1,5,23,63,332,523,754,1231};
        int[] right = new int[]{2,3,6,7,54,123,124,1234};
        int[] erg = new int[left.length+right.length];
        MergeSort m = new MergeSort();
        m.merge(left,right,erg);
        m.printArray(erg);      
    }

    private void printArray(int[] a){
        System.out.print("[");
        for(int i = 0; i < a.length ; i++){
            if(i == a.length -1){
                System.out.print(a[i]);
            }else{
                System.out.print(a[i]+",");
            }
        }
        System.out.print("]");
        System.out.println("");
    }

}

