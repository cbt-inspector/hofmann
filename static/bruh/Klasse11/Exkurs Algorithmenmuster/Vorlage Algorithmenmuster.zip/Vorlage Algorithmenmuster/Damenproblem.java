public class Damenproblem {
	

}
