import java.util.Random;
import java.util.Arrays;
import org.junit.*;
import org.junit.Assert;

public class MergeSortTest {
    private static final Random RAND = new Random(42);   // random number generator
    static int[] arr1, arr2, arr3, arr4, arr5;
    static MergeSort x;

    @BeforeClass
    public static void setup() {
        x = new MergeSort();
        arr1 = createRandomArray(8);
        arr2 = createRandomArray(1000);
        arr3 = createRandomArray(100000);
        arr4 = createRandomArray(2000001);
        arr5 = createRandomArray(20000001);

    }

    @Test
    public void testArraySize8(){
        x.mergeSort(arr1);
        Assert.assertTrue("Es wurde nicht richtig sortiert, bei Array der Länge: 8", isSorted(arr1));
    }

    @Test
    public void testArraySize1000(){
        x.mergeSort(arr2);
        Assert.assertTrue("Es wurde nicht richtig sortiert, bei Array der Länge: 1000", isSorted(arr2));
    }

    @Test
    public void testArraySize100000(){
        x.mergeSort(arr3);
        Assert.assertTrue("Es wurde nicht richtig sortiert, bei Array der Länge: 100000", isSorted(arr3));
    }

    @Test
    public void testArraySize2m1(){
        x.mergeSort(arr4);
        Assert.assertTrue("Es wurde nicht richtig sortiert, bei Array der Länge: 2000001", isSorted(arr4));
    }

    @Test
    public void testArraySize20m(){
        x.mergeSort(arr5);
        Assert.assertTrue("Es wurde nicht richtig sortiert, bei Array der Länge 20000001 und 32 Threads", isSorted(arr5));
    }


    public static boolean isSorted(int[] a) {
        for (int i = 0; i < a.length - 1; i++) {
            if (a[i] > a[i + 1]) {
                return false;
            }
        }
        return true;
    }

    public static int[] createRandomArray(int length) {
        int[] a = new int[length];
        for (int i = 0; i < a.length; i++) {
            a[i] = RAND.nextInt(1000000);
        }
        return a;
    }
}
