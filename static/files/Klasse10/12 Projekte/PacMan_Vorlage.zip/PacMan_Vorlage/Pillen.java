
/**
 * Beschreiben Sie hier die Klasse Pillen.
 * 
 * @author (Ihr Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Pillen
{

    public static RECHTECK[] gibMirPillen(){
        RECHTECK[] pillen = new RECHTECK[106];
        // Links senkrecht
        pillen[0]  = new RECHTECK ( 10 , 10 , 50 ,  50 , "gelb" );
        pillen[1]  = new RECHTECK ( 10 , 10 , 50 , 100 , "gelb" );
        pillen[2]  = new RECHTECK ( 10 , 10 , 50 , 150 , "gelb" );
        pillen[3]  = new RECHTECK ( 10 , 10 , 50 , 200 , "gelb" );
        pillen[4]  = new RECHTECK ( 10 , 10 , 50 , 250 , "gelb" );
        pillen[5]  = new RECHTECK ( 10 , 10 , 50 , 300 , "gelb" );
        pillen[6]  = new RECHTECK ( 10 , 10 , 50 , 350 , "gelb" );
        pillen[7]  = new RECHTECK ( 10 , 10 , 50 , 400 , "gelb" );
        pillen[8]  = new RECHTECK ( 10 , 10 , 50 , 450 , "gelb" );
        pillen[9]  = new RECHTECK ( 10 , 10 , 50 , 500 , "gelb" );
        pillen[10] = new RECHTECK ( 10 , 10 , 50 , 550 , "gelb" );
        // Rechts senkrecht
        pillen[11] = new RECHTECK ( 10 , 10 , 750 ,  50 , "gelb" );
        pillen[12] = new RECHTECK ( 10 , 10 , 750 , 100 , "gelb" );
        pillen[13] = new RECHTECK ( 10 , 10 , 750 , 150 , "gelb" );
        pillen[14] = new RECHTECK ( 10 , 10 , 750 , 200 , "gelb" );
        pillen[15] = new RECHTECK ( 10 , 10 , 750 , 250 , "gelb" );
        pillen[16] = new RECHTECK ( 10 , 10 , 750 , 300 , "gelb" );
        pillen[17] = new RECHTECK ( 10 , 10 , 750 , 350 , "gelb" );
        pillen[18] = new RECHTECK ( 10 , 10 , 750 , 400 , "gelb" );
        pillen[19] = new RECHTECK ( 10 , 10 , 750 , 450 , "gelb" );
        pillen[20] = new RECHTECK ( 10 , 10 , 750 , 500 , "gelb" );
        pillen[21] = new RECHTECK ( 10 , 10 , 750 , 550 , "gelb" );
        // Mitte links senkrecht
        pillen[22] = new RECHTECK ( 10 , 10 , 350 ,  50 , "gelb" );
        pillen[23] = new RECHTECK ( 10 , 10 , 350 , 100 , "gelb" );
        pillen[24] = new RECHTECK ( 10 , 10 , 350 , 150 , "gelb" );
        pillen[25] = new RECHTECK ( 10 , 10 , 350 , 200 , "gelb" );
        pillen[26] = new RECHTECK ( 10 , 10 , 350 , 250 , "gelb" );
        pillen[27] = new RECHTECK ( 10 , 10 , 350 , 300 , "gelb" );
        pillen[28] = new RECHTECK ( 10 , 10 , 350 , 350 , "gelb" );
        pillen[29] = new RECHTECK ( 10 , 10 , 350 , 400 , "gelb" );
        pillen[30] = new RECHTECK ( 10 , 10 , 350 , 450 , "gelb" );
        pillen[31] = new RECHTECK ( 10 , 10 , 350 , 500 , "gelb" );
        pillen[32] = new RECHTECK ( 10 , 10 , 350 , 550 , "gelb" );
        // Mitte Rechts senkrecht
        pillen[33] = new RECHTECK ( 10 , 10 , 450 ,  50 , "gelb" );
        pillen[34] = new RECHTECK ( 10 , 10 , 450 , 100 , "gelb" );
        pillen[35] = new RECHTECK ( 10 , 10 , 450 , 150 , "gelb" );
        pillen[36] = new RECHTECK ( 10 , 10 , 450 , 200 , "gelb" );
        pillen[37] = new RECHTECK ( 10 , 10 , 450 , 250 , "gelb" );
        pillen[38] = new RECHTECK ( 10 , 10 , 450 , 300 , "gelb" );
        pillen[39] = new RECHTECK ( 10 , 10 , 450 , 350 , "gelb" );
        pillen[40] = new RECHTECK ( 10 , 10 , 450 , 400 , "gelb" );
        pillen[41] = new RECHTECK ( 10 , 10 , 450 , 450 , "gelb" );
        pillen[42] = new RECHTECK ( 10 , 10 , 450 , 500 , "gelb" );
        pillen[43] = new RECHTECK ( 10 , 10 , 450 , 550 , "gelb" );
        // Quer 1
        pillen[44] = new RECHTECK ( 10 , 10 , 100 , 50 , "gelb" );
        pillen[45] = new RECHTECK ( 10 , 10 , 150 , 50 , "gelb" );
        pillen[46] = new RECHTECK ( 10 , 10 , 200 , 50 , "gelb" );
        pillen[47] = new RECHTECK ( 10 , 10 , 250 , 50 , "gelb" );
        pillen[48] = new RECHTECK ( 10 , 10 , 300 , 50 , "gelb" );
        pillen[49] = new RECHTECK ( 10 , 10 , 400 , 50 , "gelb" );
        pillen[50] = new RECHTECK ( 10 , 10 , 500 , 50 , "gelb" );
        pillen[51] = new RECHTECK ( 10 , 10 , 550 , 50 , "gelb" );
        pillen[52] = new RECHTECK ( 10 , 10 , 600 , 50 , "gelb" );
        pillen[53] = new RECHTECK ( 10 , 10 , 650 , 50 , "gelb" );
        pillen[54] = new RECHTECK ( 10 , 10 , 700 , 50 , "gelb" );
        // Quer 8
        pillen[55] = new RECHTECK ( 10 , 10 , 100 , 550 , "gelb" );
        pillen[56] = new RECHTECK ( 10 , 10 , 150 , 550 , "gelb" );
        pillen[57] = new RECHTECK ( 10 , 10 , 200 , 550 , "gelb" );
        pillen[58] = new RECHTECK ( 10 , 10 , 250 , 550 , "gelb" );
        pillen[59] = new RECHTECK ( 10 , 10 , 300 , 550 , "gelb" );
        pillen[60] = new RECHTECK ( 10 , 10 , 400 , 550 , "gelb" );
        pillen[61] = new RECHTECK ( 10 , 10 , 500 , 550 , "gelb" );
        pillen[62] = new RECHTECK ( 10 , 10 , 550 , 550 , "gelb" );
        pillen[63] = new RECHTECK ( 10 , 10 , 600 , 550 , "gelb" );
        pillen[64] = new RECHTECK ( 10 , 10 , 650 , 550 , "gelb" );
        pillen[65] = new RECHTECK ( 10 , 10 , 700 , 550 , "gelb" );
        // Quer 2
        pillen[66] = new RECHTECK ( 10 , 10 , 150 , 150 , "gelb" );
        pillen[67] = new RECHTECK ( 10 , 10 , 200 , 150 , "gelb" );
        pillen[68] = new RECHTECK ( 10 , 10 , 250 , 150 , "gelb" );
        pillen[69] = new RECHTECK ( 10 , 10 , 300 , 150 , "gelb" );
        pillen[70] = new RECHTECK ( 10 , 10 , 500 , 150 , "gelb" );
        pillen[71] = new RECHTECK ( 10 , 10 , 550 , 150 , "gelb" );
        pillen[72] = new RECHTECK ( 10 , 10 , 600 , 150 , "gelb" );
        pillen[73] = new RECHTECK ( 10 , 10 , 650 , 150 , "gelb" );
        // Quer 3
        pillen[74] = new RECHTECK ( 10 , 10 , 150 , 200 , "gelb" );
        pillen[75] = new RECHTECK ( 10 , 10 , 250 , 200 , "gelb" );
        pillen[76] = new RECHTECK ( 10 , 10 , 550 , 200 , "gelb" );
        pillen[77] = new RECHTECK ( 10 , 10 , 650 , 200 , "gelb" );
        // Quer 4
        pillen[78] = new RECHTECK ( 10 , 10 , 100 , 250 , "gelb" );
        pillen[79] = new RECHTECK ( 10 , 10 , 150 , 250 , "gelb" );
        pillen[80] = new RECHTECK ( 10 , 10 , 200 , 250 , "gelb" );
        pillen[81] = new RECHTECK ( 10 , 10 , 250 , 250 , "gelb" );
        pillen[82] = new RECHTECK ( 10 , 10 , 550 , 250 , "gelb" );
        pillen[83] = new RECHTECK ( 10 , 10 , 600 , 250 , "gelb" );
        pillen[84] = new RECHTECK ( 10 , 10 , 650 , 250 , "gelb" );
        pillen[85] = new RECHTECK ( 10 , 10 , 700 , 250 , "gelb" );
        // Quer 5
        pillen[86] = new RECHTECK ( 10 , 10 , 100 , 350 , "gelb" );
        pillen[87] = new RECHTECK ( 10 , 10 , 150 , 350 , "gelb" );
        pillen[88] = new RECHTECK ( 10 , 10 , 200 , 350 , "gelb" );
        pillen[89] = new RECHTECK ( 10 , 10 , 250 , 350 , "gelb" );
        pillen[90] = new RECHTECK ( 10 , 10 , 550 , 350 , "gelb" );
        pillen[91] = new RECHTECK ( 10 , 10 , 600 , 350 , "gelb" );
        pillen[92] = new RECHTECK ( 10 , 10 , 650 , 350 , "gelb" );
        pillen[93] = new RECHTECK ( 10 , 10 , 700 , 350 , "gelb" );
        // Quer 6
        pillen[94] = new RECHTECK ( 10 , 10 , 150 , 400 , "gelb" );
        pillen[95] = new RECHTECK ( 10 , 10 , 250 , 400 , "gelb" );
        pillen[96] = new RECHTECK ( 10 , 10 , 550 , 400 , "gelb" );
        pillen[97] = new RECHTECK ( 10 , 10 , 650 , 400 , "gelb" );
        // Quer 7
        pillen[98]  = new RECHTECK ( 10 , 10 , 150 , 450 , "gelb" );
        pillen[99]  = new RECHTECK ( 10 , 10 , 200 , 450 , "gelb" );
        pillen[100] = new RECHTECK ( 10 , 10 , 250 , 450 , "gelb" );
        pillen[101] = new RECHTECK ( 10 , 10 , 300 , 450 , "gelb" );
        pillen[102] = new RECHTECK ( 10 , 10 , 500 , 450 , "gelb" );
        pillen[103] = new RECHTECK ( 10 , 10 , 550 , 450 , "gelb" );
        pillen[104] = new RECHTECK ( 10 , 10 , 600 , 450 , "gelb" );
        pillen[105] = new RECHTECK ( 10 , 10 , 650 , 450 , "gelb" );
        return pillen;
    }

}
