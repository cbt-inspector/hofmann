import java.util.Random;
/**
 * Geist repraesentiert einen Geist im Spiel PacMan.
 * 
 * @author      mike_gans@yahoo.de
 * @version     1.0 (2017-01-14)
 */
public class Geist{
    // 4 unterschiedlich penetrante Verfolger
    
    // Mass fuer die Penetranz bei der Verfolgung
    
    // Zaehlt Schritte, bis Richtung aktualisiert wird
    
    // Schrittweiten
    
    // Koordinaten vor einem Schritt
    
    // Referenz auf den PacMan
    

    /**
     * Konstruktor der Klasse Geist
     */
    public Geist( int x , int y , int typ , FIGUR pac )
    {
       
    }

    public void bewegen()
    {
        // alte Position speichern
        

        // bewegen
        

        // bei Verklemmung neue zufaellige Richtung
       
        
        

        // Counter erhoehen
        

        // Je nach Penetranz auf PacMan neu ausrichten
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }

    public int zufallszahlVonBis( int von , int bis ){
        return (int)(new Random().nextInt(bis-von+1) + von);
    }

   
}
