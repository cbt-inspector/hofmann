
/**
 * Labyrinth im Spiel PacMan.
 * 
 * @author      mike_gans@yahoo.de
 * 
 * @version     1.0 (2017-01-14)    initial
 */
public class Labyrinth
{
    RECHTECK[] mauern;

    /**
     * Konstruktor der Klasse Labyrinth
     */
    public Labyrinth()
    {
        mauern = new RECHTECK[24];
        // oben, unten
        mauern[0] = new RECHTECK(800,20,400,10,"blau");
        mauern[1] = new RECHTECK(800,20,400,600,"blau");
        // links, rechts
        mauern[2] = new RECHTECK(20,600,10,300,"blau");
        mauern[3] = new RECHTECK(20,600,800,300,"blau");
        // Ecken quer
        mauern[4] = new RECHTECK(200,20,600,100,"blau");
        mauern[5] = new RECHTECK(200,20,200,100,"blau");
        mauern[6] = new RECHTECK(200,20,600,500,"blau");
        mauern[7] = new RECHTECK(200,20,200,500,"blau");
        // Mitte Stern
        mauern[8] = new RECHTECK(200,20,600,300,"blau");
        mauern[9] = new RECHTECK(200,20,200,300,"blau");
        mauern[10] = new RECHTECK(20,150,400,165,"blau");
        mauern[11] = new RECHTECK(20,150,400,435,"blau");
        // Mitte senkrecht
        mauern[12] = new RECHTECK(20,100,295,250,"blau");
        mauern[13] = new RECHTECK(20,100,295,350,"blau");
        mauern[14] = new RECHTECK(20,100,505,250,"blau");
        mauern[15] = new RECHTECK(20,100,505,350,"blau");
        // Aussen senkrecht
        mauern[16] = new RECHTECK(20,100,110,150,"blau");
        mauern[17] = new RECHTECK(20,100,690,150,"blau");
        mauern[18] = new RECHTECK(20,100,110,450,"blau");
        mauern[19] = new RECHTECK(20,100,690,450,"blau");
        // Mitte Links / Mitte Rechts senkrecht
        mauern[20] = new RECHTECK(20,50,205,200,"blau");
        mauern[21] = new RECHTECK(20,50,595,200,"blau");
        mauern[22] = new RECHTECK(20,50,205,400,"blau");
        mauern[23] = new RECHTECK(20,50,595,400,"blau");
        
        for ( int i=0 ; i<24 ;i++ )
        {
            mauern[i].passivMachen();
        }
    }

    
}
