public class DatentypUmwandler {
    
    
    public DatentypUmwandler(){
    }
    
    public int stringToInt(String s){
        return Integer.parseInt(s);
    }
    
    
}