
public class FIBONACCI{
    
    int[] fibzahlen;
    
    public FIBONACCI(int laenge){
       fibzahlen = new int[laenge];
       fibzahlen[0] = 0;
       fibzahlen[1] = 1;
       for(int i = 2; i < fibzahlen.length; i = i + 1){
           fibzahlen[i] = fibzahlen[i-1] + fibzahlen[i-2];
       }
       
       //Ausgabe
       for(int i = 0; i < fibzahlen.length; i = i + 1){
           System.out.print(fibzahlen[i]+" ");
       }
    }

    
}
