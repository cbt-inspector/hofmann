
public class HIGHSCORE{
   
    int[] punktestaende;
    String[] namensliste;
    
    public HIGHSCORE(){
        punktestaende = new int[10];
        namensliste = new String[10];
        
        namensliste[0] = "Sepp";
        namensliste[1] = "Susi";
        
        punktestaende[0] = 12000;
        punktestaende[1] = 7500;
    }
    
    public String nenneRang(int platznummer){
        //Name + ein Leerzeichen + Punkte
        return namensliste[platznummer]+" "+punktestaende[platznummer];
    }
    
    public void setzeRang(int platznummer, String name, int punkte){
        namensliste[platznummer] = name;
        punktestaende[platznummer] = punkte;
    }
    
    public void nenneAlleRaenge(){
        for(int i = 0; i < namensliste.length; i=i+1){
            System.out.println(namensliste[i]+" "+punktestaende[i]);
        }
    }

    
}
