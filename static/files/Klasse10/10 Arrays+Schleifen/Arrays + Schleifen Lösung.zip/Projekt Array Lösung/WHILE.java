
public class WHILE{
    
    public WHILE(){
        int i = 0;
        while(i < 10){
            //Irgendwas tun
            
            i++;
        }
        
        
    }

   
}
