public class MEINSPIEL extends SPIEL{
    FIGUR obb;
    FIGUR[] plattformen;

    public MEINSPIEL(){
        super();
        obb = new FIGUR("obb.png");
        plattformen = new FIGUR[50];
        obb.macheAktiv();
        setzeKamerafokus(obb);
        
        
        //TODO plattformen erstellen
        for(int i = 0; i < plattformen.length; i++){
            plattformen[i] = new FIGUR("plattform.png");
            if(i % 2 == 0){
                plattformen[i].setzeMittelpunkt(i*6-10, -5);
            } else {
                plattformen[i].setzeMittelpunkt(i*6-10, -3);
            }
            plattformen[i].machePassiv();
        }

        
        tickerNeuStarten(0.07);   
    }

    public void tick(){
        if(tasteGedrueckt(TASTE.RECHTS)){
            obb.verschiebenUm(0.5, 0);
        }
        if(tasteGedrueckt(TASTE.LINKS)){
            obb.verschiebenUm(-0.2, 0);
        }
    }

    public void tasteReagieren(int taste){
        if(taste == TASTE.RAUF){
            obb.springe(12);
        }
    }

    
}