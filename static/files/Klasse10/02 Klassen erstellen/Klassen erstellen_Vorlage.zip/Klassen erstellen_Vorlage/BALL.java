
public class BALL {
    
    int radius;
    String farbe;
    
            
    public BALL(int r, String f) {
        this.radius = r;
        this.farbe = f;    
    }
    
 
    public int nenneRadius() {
        return this.radius;
    }
    
    
    public void setzeRadius(int rNeu) {
        this.radius = rNeu;
    }
    
}
