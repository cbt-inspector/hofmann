public class Hund{
    private int alter;
    private String name;

    public Hund(int alter, String name){
        this.alter = alter;
        this.name = name;
    }
    
    public void bellen(){
        System.out.println("Hund: Wau wau wau !");
    }

    
}
