
public class FAHRRAD{

    public FAHRRAD(){
        
    }

}
