
public class PERSON{
    FAHRRAD hauptrad;
    FAHRRAD ersatzrad;
    public PERSON(){
        //noch zeigen die beiden Referenz auf kein Objekt -> null
        System.out.println(hauptrad); 
        System.out.println(ersatzrad);
        
        hauptrad = new FAHRRAD(); //f1
        ersatzrad = new FAHRRAD(); //f2 
        System.out.println("Beginn: Hauptrad "+hauptrad);
        System.out.println("Beginn: Ersatzrad "+ersatzrad);
        
        
        //Die PERSON möchte sich ein neues Fahrrad kaufen
        //Somit macht sie das Hauptrad zum neuen Ersatzrad    
        ersatzrad = hauptrad;
        System.out.println("Radtausch: Hauptrad "+hauptrad);
        System.out.println("Radtausch: Ersatzrad "+ersatzrad);
        
        
        //und kauft sich ein neuen Hauptrad
        hauptrad = new FAHRRAD();
        System.out.println("Neues Rad gekauft: Hauptrad "+hauptrad);
        System.out.println("Neues Rad gekauft: Ersatzrad "+ersatzrad);
        
        
        //Hauptrad geht kaputt und diese Objekt gibt es nicht mehr
        hauptrad = null;
        System.out.println("Hauptrad kaputt: "+hauptrad);
        
        //Zusatzinfo: Objekte können in Java nicht direkt gelöscht werden
        //Falls keine Referenz mehr auf ein Objekt zeigt wird dieses 
        //bei Gelegenheit vom Garbage Collector einsammelt bw. gelöscht
        
        
    }



}
