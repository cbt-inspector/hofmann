
public class REKURSION
{
 
    public REKURSION(){
        
    }
    
    public int fakultaet(int n){
        return 0;
    }
    
    public int mal(int a, int b){
        return 0;
    }
    
     public int potenz(int basis, int exponent){
        return 0;
    }
       
    

    //Fibonacci-Folge -> Siehe Wikipedia
    public int fibonacci(int n){
        return 0;
    }
        
    
    //Collatz-Problem: ungelöstes/bewiesenes Problem in der Mathematik -> siehe Wikipedia
    //Jede so konstruierte Zahlenfolge wird irgendwann 1, egal mit welcher Zahl man beginnt.
    //Parameter: aktuelle Zahl bzw. Startwert und die n-te Zahl der Collatzfolge (mit einer bestimmten Zahl)
    //Test auf gerade und ungerade Zahl über Modulo-Rechnung -> Googlen    
    public int collatz(int zahl, int n){
        return 0;
    }
    
    
}

    
