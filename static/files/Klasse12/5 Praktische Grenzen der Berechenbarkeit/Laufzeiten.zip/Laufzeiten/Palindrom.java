
public class Palindrom {
    
    private char [] a;
    
    public Palindrom(String s){
        a = s.toCharArray();
    }
    
    public boolean istPalindrom() {
        int n = a.length;
        for (int i = 0; i <= n/2; i++) {
            if (a[i] != a[n - 1 - i]) {
                return false;
            }
        }
        return true;
    }
}
