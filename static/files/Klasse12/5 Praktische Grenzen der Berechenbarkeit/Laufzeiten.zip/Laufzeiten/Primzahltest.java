
public class Primzahltest {
    
    private int p;
    
    public Primzahltest(int a) {
        p = a;
    }

    public boolean test(){
        int sqrt = (int) Math.sqrt(p);
        
        for(int i=2; i < sqrt; i++){
            
            if(p % i == 0){
                return false;
            }
            
        }
        return true;
    }
}
