
public class Hardcore { //Schleifenanalyse
    
    public void foo1(int n) {
        for (int i = 0; i < n; i++) {
            for (int j = n; j > 0; j--) {
                bar(n);  // die Methode bar(n) besitzt den Aufwand log2(n)
            }
        }
    }
    
    public void foo2(int n) {
        for (int i = 0; i < n; i++) {
            for (int j = i / 2; j > 0; j--) {
                bar(n);  // die Methode bar(n) besitzt den Aufwand log2(n)
            }
        }
    }

    public void foo3(int n) {
        for (int i = 0; i < n; i++) {
            for (int j = i; j >= 1; j /= 2) {
                bar(n);  // die Methode bar(n) besitzt den Aufwand log2(n)
            }
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public int bar(int n){
        return 0;
    }
    
    

}
