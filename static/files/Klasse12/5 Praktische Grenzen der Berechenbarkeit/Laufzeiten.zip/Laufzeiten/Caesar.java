public class Caesar {

    private char[] a;

    public Caesar(String s){
        this.a = s.toCharArray();
    }

    public void verschluesseln(int offset) {

        char[] cryptArray = new char[a.length];
        // erstmal ein leeres Char Array erstellen

        for (int i = 0; i < a.length; i++) {

            int verschiebung = (a[i] + offset)%128;
            // ursprüngliches Zeichen plus Offset modulo 128

            cryptArray[i] = (char) (verschiebung);

        }
        System.out.println(String.valueOf(cryptArray));

    }
}