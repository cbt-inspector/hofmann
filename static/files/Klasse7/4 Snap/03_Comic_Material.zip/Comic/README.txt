Quellen: 

Bildquellen: 

Kevin-lachend.png: https://www.youtube.com/watch?v=Xxumrq2tkx0
Kevin-normal.png: https://www.youtube.com/watch?v=Xxumrq2tkx0
Spritze-Bild.png: https://www.youtube.com/watch?v=Xxumrq2tkx0
Stuart-boese.png: https://www.youtube.com/watch?v=Xxumrq2tkx0
Stuart-normal.png: https://www.youtube.com/watch?v=Xxumrq2tkx0

Soundquellen:

Bah.mp3: https://www.youtube.com/watch?v=Xxumrq2tkx0
Lachen.mp3: https://www.youtube.com/watch?v=Xxumrq2tkx0
Spritze-Sound.mp3: https://www.youtube.com/watch?v=Xxumrq2tkx0